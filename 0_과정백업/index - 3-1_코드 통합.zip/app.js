/*
 * Hyundai SmartSense tailgate obstacle-detection experience
 *
 * This file intentionally uses plain, readable JavaScript with no build step.
 * To change the source footage, edit VIDEO_SOURCE below.
 */

const VIDEO_SOURCE = "./소스영상.mp4";

const DEFAULT_POSITION = { x: 84, y: 67 };
const OBJECT_LABELS = {
  box: "택배 박스",
  cart: "쇼핑 카트",
  luggage: "캐리어",
};

const STATUS_MESSAGES = {
  armed: {
    code: "SYSTEM READY",
    title: "감지 보조 활성화",
    detail: "테일게이트를 열어 미션을 시작하세요",
    tone: "ready",
    icon: "◉",
  },
  opening: {
    code: "RADAR SCANNING",
    title: "열림 영역 감지 중",
    detail: "장애물을 차량 뒤로 드래그하세요",
    tone: "scan",
    icon: "◉",
  },
  stopped: {
    code: "OBSTACLE DETECTED",
    title: "충돌 전 자동 정지",
    detail: "장애물을 감지 영역 밖으로 옮기세요",
    tone: "danger",
    icon: "!",
  },
  checking: {
    code: "CLEARANCE CHECK",
    title: "안전 거리 확인",
    detail: "영역을 비워 두세요",
    tone: "checking",
    icon: "3",
  },
  reopening: {
    code: "SAFE TO OPEN",
    title: "자동 재열림 작동",
    detail: "안전 위치까지 다시 열립니다",
    tone: "safe",
    icon: "✓",
  },
  success: {
    code: "MISSION COMPLETE",
    title: "테일게이트 열림 완료",
    detail: "장애물 회피에 성공했습니다",
    tone: "success",
    icon: "✓",
  },
  missed: {
    code: "TRY AGAIN",
    title: "장애물을 감지하지 못했어요",
    detail: "열리는 동안 물체를 영역 안으로 옮기세요",
    tone: "missed",
    icon: "◉",
  },
};

const MISSION_BANNERS = {
  armed: ["READY", "테일게이트를 열고 장애물을 준비하세요"],
  opening: ["MISSION 02", "물체를 잡아 레이더 영역 안으로 드래그!"],
  stopped: ["MISSION 03", "정지 성공! 이제 물체를 멀리 옮기세요"],
  checking: ["HOLD CLEAR", "안전 판정이 끝날 때까지 영역을 비우세요"],
  reopening: ["AUTO REOPEN", "다시 넣으면 테일게이트가 또 멈춥니다"],
  success: ["COMPLETE", "실제 작동 흐름을 모두 체험했습니다"],
  missed: ["RETRY", "열림이 끝나기 전에 장애물을 넣어보세요"],
};

const app = {
  phase: "intro",
  objectType: "box",
  position: { ...DEFAULT_POSITION },
  obstacleInside: false,
  hasDragged: false,
  countdown: 3,
  score: 0,
  progress: 0,
  stopCount: 0,
  detectedOnce: false,
  soundOn: true,
  dragging: false,
  startedAt: 0,
  elapsed: 0,
  checkTimers: [],
  elapsedTimer: null,
};

const root = document.querySelector("#root");

root.innerHTML = `
  <main class="game-shell phase-intro">
    <header class="game-topbar">
      <div class="game-brand">
        <span class="hyundai-mark" aria-label="Hyundai">
          <svg viewBox="0 0 68 36" aria-hidden="true">
            <ellipse cx="34" cy="18" rx="31" ry="15"></ellipse>
            <path d="M18 26 28 10M27 24l14-13M27 18h14M41 11l10 15"></path>
          </svg>
        </span>
        <b>HYUNDAI</b><i></i><span>SMARTSENSE<br>EXPERIENCE</span>
      </div>

      <div class="mission-progress" aria-label="미션 진행 상태">
        <div class="mission-step" data-step="1"><span>01</span><strong>기능 켜기</strong></div>
        <div class="mission-step" data-step="2"><span>02</span><strong>장애물 감지</strong></div>
        <div class="mission-step" data-step="3"><span>03</span><strong>안전 재열림</strong></div>
      </div>

      <div class="game-stats">
        <span><small>SCORE</small><b data-score>0000</b></span>
        <span><small>TIME</small><b data-time>0.0</b></span>
        <a href="./index.html" download aria-label="HTML 다운로드">↓</a>
      </div>
    </header>

    <section class="game-stage" data-stage>
      <video
        class="game-video"
        src="${VIDEO_SOURCE}"
        muted
        playsinline
        preload="auto"
      ></video>
      <div class="stage-grade"></div>
      <div class="stage-grid"></div>
      <div class="scan-line"></div>

      <div class="radar-zone" aria-hidden="true">
        <i></i><i></i><i></i><span>RADAR DETECTION ZONE</span>
      </div>

      <div class="mission-banner" hidden>
        <small data-banner-code></small>
        <strong data-banner-text></strong>
      </div>

      <div class="status-toast" aria-live="polite" hidden>
        <span class="status-glyph" data-status-icon></span>
        <div>
          <small data-status-code></small>
          <strong data-status-title></strong>
          <p data-status-detail></p>
        </div>
      </div>

      <div class="telemetry left-telemetry">
        <span><small>POWER TAILGATE</small><b data-tailgate-state>READY</b></span>
        <i><b data-tailgate-progress></b></i>
      </div>

      <div class="telemetry right-telemetry">
        <span><small>RADAR STATUS</small><b data-radar-state>OFF</b></span>
        <em data-distance>0.84 m</em>
      </div>

      <aside class="object-dock" hidden>
        <small>CHOOSE OBJECT</small>
        <div>
          ${Object.keys(OBJECT_LABELS)
            .map(
              (type) => `
                <button type="button" data-object="${type}">
                  <span data-object-graphic="${type}"></span>
                  <span>${OBJECT_LABELS[type]}</span>
                </button>`,
            )
            .join("")}
        </div>
      </aside>

      <button class="drag-obstacle box" type="button" hidden>
        <i class="drag-pulse" hidden></i>
        <span data-drag-graphic></span>
        <span class="drag-label">DRAG ME</span>
      </button>

      <div class="particle-field" aria-hidden="true" hidden>
        ${Array.from({ length: 20 }, (_, index) => `<i style="--i:${index}"></i>`).join("")}
      </div>

      <div class="stage-actions">
        <button class="open-button" type="button" data-action="open" hidden>
          <span>POWER TAILGATE</span><strong>테일게이트 열기</strong><i>→</i>
        </button>
        <button class="open-button retry" type="button" data-action="retry" hidden>
          <span>MISSION FAILED</span><strong>다시 도전하기</strong><i>↻</i>
        </button>
        <button class="open-button success-button" type="button" data-action="replay" hidden>
          <span>MISSION COMPLETE</span><strong>다른 물체로 다시 체험</strong><i>↻</i>
        </button>
      </div>

      <div class="game-tools">
        <button type="button" data-action="sound" aria-label="효과음 끄기">◕</button>
        <button type="button" data-action="help" aria-label="도움말">?</button>
        <button type="button" data-action="home" aria-label="처음부터">↻</button>
      </div>

      <div class="timeline"><i data-timeline></i><span data-timeline-handle></span></div>
    </section>

    <footer class="game-footer">
      <div>
        <span data-footer-step="1">1 <b>드래그해서 막기</b></span>
        <span data-footer-step="2">2 <b>장애물 치우기</b></span>
        <span data-footer-step="3">3 <b>자동 재열림 확인</b></span>
      </div>
      <p>물체는 마우스·손가락으로 이동할 수 있습니다. 재열림 중 다시 넣어 반복 정지도 시험해 보세요.</p>
    </footer>

    <div class="overlay-screen intro-overlay">
      <section class="intro-card">
        <span class="intro-kicker"><i></i> REAL-WORLD SIMULATION</span>
        <h1>테일게이트를<br><em>직접 막아보세요.</em></h1>
        <p>열리는 동안 물체를 차량 뒤로 가져가고, 자동 정지 후 다시 멀리 옮겨 기능의 판단 과정을 체험합니다.</p>
        <div class="intro-missions">
          <span><b>01</b>기능 활성화</span>
          <span><b>02</b>장애물 드래그</span>
          <span><b>03</b>자동 재열림</span>
        </div>
        <button type="button" data-action="start"><span>체험 시작</span><i>→</i></button>
        <small>약 30초 · 마우스 / 터치 지원</small>
      </section>
    </div>

    <div class="overlay-screen settings-overlay" role="dialog" aria-modal="true" aria-label="차량 설정" hidden>
      <section class="settings-console">
        <header>
          <button type="button" data-action="close-settings" aria-label="설정 닫기">←</button>
          <div><small>차량 설정</small><strong>도어</strong></div>
          <span>10:42</span>
        </header>
        <div class="settings-body">
          <nav aria-label="차량 설정 메뉴">
            <span>운전자 보조</span><span>시트</span><span>공조</span><b>도어</b><span>라이트</span>
          </nav>
          <div class="door-settings">
            <div class="setting-title"><small>DOOR SETTINGS</small><h2>테일게이트</h2></div>
            <div class="setting-option muted">
              <span>↗</span><div><strong>스마트 파워 테일게이트</strong><small>접근 시 자동 열림</small></div><i>›</i>
            </div>
            <button class="setting-option featured" type="button" data-action="show-confirm">
              <span class="radar-dot">◉</span>
              <div><strong>테일게이트 장애물 감지 보조</strong><small>출고 시 기본 OFF</small></div>
              <i class="switch"><b></b></i>
            </button>
            <p class="setting-help"><b>i</b> 파워 테일게이트 열림 중 후방·천장 장애물을 감지하면 자동으로 멈춥니다.</p>
          </div>
        </div>
      </section>

      <section class="setting-confirm" role="alertdialog" aria-modal="true" hidden>
        <span class="confirm-icon">!</span>
        <small>기능 활성화</small>
        <h2>감지 보조를 켤까요?</h2>
        <p>레이더 센서가 테일게이트 열림 영역을 감지합니다. 주변 안전을 직접 확인한 후 사용하세요.</p>
        <div><span>✓ 충돌 위험 시 자동 정지</span><span>✓ 안전 확인 시 자동 재열림</span></div>
        <footer>
          <button type="button" data-action="hide-confirm">취소</button>
          <button type="button" data-action="activate">확인하고 켜기</button>
        </footer>
      </section>
    </div>

    <div class="overlay-screen help-overlay" role="dialog" aria-modal="true" aria-label="플레이 방법" hidden>
      <section>
        <button type="button" data-action="close-help" aria-label="도움말 닫기">×</button>
        <small>HOW TO PLAY</small>
        <h2>실제처럼 움직여 보세요.</h2>
        <ol>
          <li><b>1</b><span>테일게이트 열기 버튼을 누릅니다.</span></li>
          <li><b>2</b><span>물체를 잡아 점선 레이더 영역으로 드래그합니다.</span></li>
          <li><b>3</b><span>자동 정지 후 물체를 밖으로 옮겨 재열림을 확인합니다.</span></li>
          <li><b>+</b><span>재열림 중 다시 넣으면 반복 정지됩니다.</span></li>
        </ol>
        <p>장애물 재질·형태·환경에 따라 실제 감지 성능이 달라질 수 있습니다.</p>
      </section>
    </div>
  </main>
`;

const elements = {
  shell: root.querySelector(".game-shell"),
  stage: root.querySelector("[data-stage]"),
  video: root.querySelector(".game-video"),
  radarZone: root.querySelector(".radar-zone"),
  banner: root.querySelector(".mission-banner"),
  status: root.querySelector(".status-toast"),
  objectDock: root.querySelector(".object-dock"),
  obstacle: root.querySelector(".drag-obstacle"),
  dragPulse: root.querySelector(".drag-pulse"),
  dragLabel: root.querySelector(".drag-label"),
  particleField: root.querySelector(".particle-field"),
  intro: root.querySelector(".intro-overlay"),
  settings: root.querySelector(".settings-overlay"),
  confirm: root.querySelector(".setting-confirm"),
  help: root.querySelector(".help-overlay"),
  openButton: root.querySelector('[data-action="open"]'),
  retryButton: root.querySelector('[data-action="retry"]'),
  replayButton: root.querySelector('[data-action="replay"]'),
  soundButton: root.querySelector('[data-action="sound"]'),
};

function objectGraphicMarkup(type) {
  if (type === "cart") {
    return "<i></i><span></span><b></b><b></b>";
  }

  if (type === "luggage") {
    return "<i></i><span></span><b></b><b></b>";
  }

  return "<i></i><span>H</span>";
}

function renderObjectGraphic(holder, type) {
  holder.className = `${type}-graphic`;
  holder.innerHTML = objectGraphicMarkup(type);
}

function setHidden(element, shouldHide) {
  element.hidden = shouldHide;
}

function isActiveMovement() {
  return ["opening", "stopped", "checking", "reopening"].includes(app.phase);
}

function isExperienceVisible() {
  return !["intro", "settings"].includes(app.phase);
}

function setPhase(nextPhase) {
  clearCheckTimers();
  app.phase = nextPhase;

  if (nextPhase === "checking") {
    startClearanceCheck();
  }

  updateInterface();
}

function updateInterface() {
  const phase = app.phase;
  const experienceVisible = isExperienceVisible();
  const movementActive = isActiveMovement();
  const reopeningComplete = ["reopening", "success"].includes(phase);

  elements.shell.className = `game-shell phase-${phase}${app.obstacleInside ? " obstacle-inside" : ""}`;
  setHidden(elements.intro, phase !== "intro");
  setHidden(elements.settings, phase !== "settings");
  setHidden(elements.objectDock, !experienceVisible);
  setHidden(elements.obstacle, !experienceVisible);
  setHidden(elements.banner, !experienceVisible);
  setHidden(elements.status, !STATUS_MESSAGES[phase]);
  setHidden(elements.openButton, phase !== "armed");
  setHidden(elements.retryButton, phase !== "missed");
  setHidden(elements.replayButton, phase !== "success");
  setHidden(elements.particleField, phase !== "success");
  setHidden(elements.dragPulse, !(phase === "opening" && !app.hasDragged));

  elements.radarZone.classList.toggle("visible", movementActive);
  updateMissionProgress(reopeningComplete);
  updateBanner();
  updateStatus();
  updateTelemetry();
  updateObjectControls(movementActive);
  updateFooter(reopeningComplete);
  updateScoreAndTime();
  updateProgress();
}

function updateMissionProgress(reopeningComplete) {
  const stepStates = {
    1: isExperienceVisible() ? "done" : app.phase === "settings" ? "active" : "idle",
    2: app.stopCount > 0 ? "done" : app.phase === "opening" ? "active" : "idle",
    3: reopeningComplete ? "done" : ["stopped", "checking"].includes(app.phase) ? "active" : "idle",
  };

  root.querySelectorAll("[data-step]").forEach((step) => {
    const state = stepStates[step.dataset.step];
    step.className = `mission-step ${state}`;
    step.querySelector("span").textContent = state === "done" ? "✓" : `0${step.dataset.step}`;
  });
}

function updateBanner() {
  const [code = "", text = ""] = MISSION_BANNERS[app.phase] || [];
  elements.banner.className = `mission-banner ${app.phase}`;
  root.querySelector("[data-banner-code]").textContent = code;
  root.querySelector("[data-banner-text]").textContent = text;
}

function updateStatus() {
  const status = STATUS_MESSAGES[app.phase];
  if (!status) return;

  const isChecking = app.phase === "checking";
  elements.status.className = `status-toast ${status.tone}`;
  root.querySelector("[data-status-icon]").textContent = isChecking ? app.countdown : status.icon;
  root.querySelector("[data-status-code]").textContent = status.code;
  root.querySelector("[data-status-title]").textContent = isChecking
    ? `${app.countdown} · ${status.title}`
    : status.title;
  root.querySelector("[data-status-detail]").textContent = status.detail;
}

function updateTelemetry() {
  const tailgateStates = {
    opening: "OPENING",
    stopped: "PAUSED",
    checking: "PAUSED",
    reopening: "REOPENING",
    success: "OPEN",
  };

  root.querySelector("[data-tailgate-state]").textContent = tailgateStates[app.phase] || "READY";
  root.querySelector("[data-radar-state]").textContent = app.obstacleInside
    ? "OBSTACLE"
    : isExperienceVisible()
      ? "ACTIVE"
      : "OFF";

  const distance = root.querySelector("[data-distance]");
  distance.textContent = app.obstacleInside ? "0.22 m" : "0.84 m";
  distance.classList.toggle("alert", app.obstacleInside);
}

function updateObjectControls(movementActive) {
  root.querySelectorAll("[data-object]").forEach((button) => {
    const selected = button.dataset.object === app.objectType;
    button.classList.toggle("selected", selected);
    button.disabled = movementActive;
  });

  root.querySelectorAll("[data-object-graphic]").forEach((holder) => {
    renderObjectGraphic(holder, holder.dataset.objectGraphic);
  });
  renderObjectGraphic(root.querySelector("[data-drag-graphic]"), app.objectType);

  elements.obstacle.className = `drag-obstacle ${app.objectType}`;
  elements.obstacle.style.left = `${app.position.x}%`;
  elements.obstacle.style.top = `${app.position.y}%`;
  elements.obstacle.setAttribute(
    "aria-label",
    `${OBJECT_LABELS[app.objectType]} 드래그. 방향키로도 이동 가능`,
  );
  elements.dragLabel.textContent = app.obstacleInside ? "DETECTED" : "DRAG ME";
}

function updateFooter(reopeningComplete) {
  const footerStates = {
    1: app.phase === "opening" ? "active" : app.stopCount > 0 ? "done" : "",
    2: ["stopped", "checking"].includes(app.phase) ? "active" : reopeningComplete ? "done" : "",
    3: app.phase === "reopening" ? "active" : app.phase === "success" ? "done" : "",
  };

  root.querySelectorAll("[data-footer-step]").forEach((step) => {
    step.className = footerStates[step.dataset.footerStep];
  });
}

function updateScoreAndTime() {
  root.querySelector("[data-score]").textContent = String(app.score).padStart(4, "0");
  root.querySelector("[data-time]").textContent = app.elapsed.toFixed(1);
}

function updateProgress() {
  const width = `${app.progress}%`;
  root.querySelector("[data-tailgate-progress]").style.width = width;
  root.querySelector("[data-timeline]").style.width = width;
  root.querySelector("[data-timeline-handle]").style.left = width;
}

function updateObstaclePosition() {
  elements.obstacle.style.left = `${app.position.x}%`;
  elements.obstacle.style.top = `${app.position.y}%`;
}

function positionIsInsideRadar(position) {
  return position.x >= 10 && position.x <= 58 && position.y >= 28 && position.y <= 83;
}

function moveObstacle(position) {
  app.position = {
    x: Math.max(5, Math.min(94, position.x)),
    y: Math.max(15, Math.min(88, position.y)),
  };
  app.hasDragged = true;
  updateObstaclePosition();
  setHidden(elements.dragPulse, true);

  const isInside = positionIsInsideRadar(app.position);
  if (isInside !== app.obstacleInside) {
    handleObstacleChange(isInside);
  }
}

function handleObstacleChange(isInside) {
  app.obstacleInside = isInside;

  if (isInside && ["opening", "reopening", "checking"].includes(app.phase)) {
    elements.video.pause();
    app.stopCount += 1;

    if (!app.detectedOnce) {
      app.detectedOnce = true;
      app.score += 350;
    }

    playTone(190, 0.26, "sawtooth");
    window.setTimeout(() => playTone(145, 0.2, "square"), 90);
    setPhase("stopped");
    return;
  }

  if (!isInside && app.phase === "stopped") {
    app.countdown = 3;
    playTone(470, 0.08);
    setPhase("checking");
    return;
  }

  updateInterface();
}

function startClearanceCheck() {
  app.checkTimers = [
    window.setTimeout(() => {
      app.countdown = 2;
      updateStatus();
    }, 560),
    window.setTimeout(() => {
      app.countdown = 1;
      updateStatus();
    }, 1120),
    window.setTimeout(() => {
      if (app.obstacleInside) return;
      app.score += 200;
      playTone(760, 0.13);
      setPhase("reopening");
      elements.video.play().catch(handleVideoError);
    }, 1700),
  ];
}

function clearCheckTimers() {
  app.checkTimers.forEach(window.clearTimeout);
  app.checkTimers = [];
}

function startExperience() {
  setPhase("settings");
}

function activateFeature() {
  setHidden(elements.confirm, true);
  app.score = 200;
  playTone(660, 0.1);
  window.setTimeout(() => playTone(880, 0.12), 100);
  setPhase("armed");
}

function openTailgate() {
  resetAttemptState();
  app.score = 200;
  app.startedAt = performance.now();
  startElapsedTimer();
  elements.video.currentTime = 0;
  elements.video.muted = true;
  playTone(520, 0.08);
  setPhase("opening");
  elements.video.play().catch(handleVideoError);
}

function retryExperience() {
  resetAttemptState();
  app.score = 200;
  elements.video.pause();
  elements.video.currentTime = 0;
  setPhase("armed");
}

function resetAttemptState() {
  clearCheckTimers();
  stopElapsedTimer();
  app.position = { ...DEFAULT_POSITION };
  app.obstacleInside = false;
  app.hasDragged = false;
  app.countdown = 3;
  app.progress = 0;
  app.stopCount = 0;
  app.detectedOnce = false;
  app.elapsed = 0;
}

function returnHome() {
  elements.video.pause();
  elements.video.currentTime = 0;
  resetAttemptState();
  app.score = 0;
  setHidden(elements.confirm, true);
  setHidden(elements.help, true);
  setPhase("intro");
}

function startElapsedTimer() {
  stopElapsedTimer();
  app.elapsedTimer = window.setInterval(() => {
    if (!isActiveMovement()) return;
    app.elapsed = (performance.now() - app.startedAt) / 1000;
    updateScoreAndTime();
  }, 100);
}

function stopElapsedTimer() {
  if (app.elapsedTimer) window.clearInterval(app.elapsedTimer);
  app.elapsedTimer = null;
}

function updateVideoProgress() {
  if (!Number.isFinite(elements.video.duration) || elements.video.duration === 0) return;
  app.progress = (elements.video.currentTime / elements.video.duration) * 100;
  updateProgress();
}

function finishVideo() {
  app.progress = 100;
  app.elapsed = app.startedAt ? (performance.now() - app.startedAt) / 1000 : app.elapsed;
  stopElapsedTimer();

  if (app.detectedOnce) {
    app.score += Math.max(100, 250 - Math.floor(app.elapsed * 8));
    playTone(660, 0.12);
    window.setTimeout(() => playTone(880, 0.14), 120);
    window.setTimeout(() => playTone(1100, 0.2), 250);
    setPhase("success");
  } else {
    playTone(180, 0.25, "triangle");
    setPhase("missed");
  }
}

function handleVideoError(error) {
  console.warn("영상을 재생하지 못했습니다. 소스 파일 경로를 확인하세요.", error);
}

function playTone(frequency, duration = 0.1, type = "sine") {
  if (!app.soundOn) return;

  try {
    app.audioContext ||= new window.AudioContext();
    const oscillator = app.audioContext.createOscillator();
    const gain = app.audioContext.createGain();
    oscillator.type = type;
    oscillator.frequency.value = frequency;
    gain.gain.setValueAtTime(0.055, app.audioContext.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, app.audioContext.currentTime + duration);
    oscillator.connect(gain).connect(app.audioContext.destination);
    oscillator.start();
    oscillator.stop(app.audioContext.currentTime + duration);
  } catch (error) {
    console.debug("효과음을 재생할 수 없습니다.", error);
  }
}

function pointerPosition(event) {
  const bounds = elements.stage.getBoundingClientRect();
  return {
    x: ((event.clientX - bounds.left) / bounds.width) * 100,
    y: ((event.clientY - bounds.top) / bounds.height) * 100,
  };
}

elements.obstacle.addEventListener("pointerdown", (event) => {
  if (["intro", "settings", "success", "missed"].includes(app.phase)) return;
  app.dragging = true;
  event.currentTarget.setPointerCapture(event.pointerId);
  moveObstacle(pointerPosition(event));
});

elements.obstacle.addEventListener("pointermove", (event) => {
  if (app.dragging) moveObstacle(pointerPosition(event));
});

function stopDragging(event) {
  app.dragging = false;
  if (event.currentTarget.hasPointerCapture(event.pointerId)) {
    event.currentTarget.releasePointerCapture(event.pointerId);
  }
}

elements.obstacle.addEventListener("pointerup", stopDragging);
elements.obstacle.addEventListener("pointercancel", stopDragging);

elements.obstacle.addEventListener("keydown", (event) => {
  const movements = {
    ArrowLeft: { x: -3, y: 0 },
    ArrowRight: { x: 3, y: 0 },
    ArrowUp: { x: 0, y: -3 },
    ArrowDown: { x: 0, y: 3 },
  };
  const movement = movements[event.key];
  if (!movement) return;

  event.preventDefault();
  moveObstacle({
    x: app.position.x + movement.x,
    y: app.position.y + movement.y,
  });
});

root.querySelectorAll("[data-object]").forEach((button) => {
  button.addEventListener("click", () => {
    if (isActiveMovement()) return;
    app.objectType = button.dataset.object;
    updateObjectControls(false);
  });
});

root.querySelector('[data-action="start"]').addEventListener("click", startExperience);
root.querySelector('[data-action="close-settings"]').addEventListener("click", () => setPhase("intro"));
root.querySelector('[data-action="show-confirm"]').addEventListener("click", () => setHidden(elements.confirm, false));
root.querySelector('[data-action="hide-confirm"]').addEventListener("click", () => setHidden(elements.confirm, true));
root.querySelector('[data-action="activate"]').addEventListener("click", activateFeature);
elements.openButton.addEventListener("click", openTailgate);
elements.retryButton.addEventListener("click", retryExperience);
elements.replayButton.addEventListener("click", retryExperience);
root.querySelector('[data-action="home"]').addEventListener("click", returnHome);
root.querySelector('[data-action="help"]').addEventListener("click", () => setHidden(elements.help, false));
root.querySelector('[data-action="close-help"]').addEventListener("click", () => setHidden(elements.help, true));

elements.soundButton.addEventListener("click", () => {
  app.soundOn = !app.soundOn;
  elements.soundButton.textContent = app.soundOn ? "◕" : "◔";
  elements.soundButton.setAttribute("aria-label", app.soundOn ? "효과음 끄기" : "효과음 켜기");
});

elements.video.addEventListener("timeupdate", updateVideoProgress);
elements.video.addEventListener("ended", finishVideo);

updateInterface();
